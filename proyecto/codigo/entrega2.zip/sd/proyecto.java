import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 *  codigo basado en la posible solucion que hay en github
 * @author David Alzate Cardona
 * @author Laura Alzate Madrid
 */
public class proyecto {
       /** Metodo auxiliar que llama al metodo recorrido posterior
    * con cada uno de los vertices
    * @param g grafo dado 
     * @param o nodo desde el cual empieza el recorrido 
    * @param d nodo donde termina el recorrido
    * @return cual es el costo que tiene
    */
public static int hayCamino2(Graph g, int o, int d){
        boolean[] visitados = new boolean[g.size()+1];    
        return hayCaminoAux2(g, o, d, visitados);
    }
  /**
    * Metodo que recorre el grafo por medio de dfs teniendo en cuenta que
    * se quiere encontrar el de menor costo
    * @param g grafo dado 
    * @param o nodo desde el cual empieza el recorrido 
    * @param d nodo donde termina el recorrido
    * @return cual es el costo que tiene ir desde inicio a fin
    */
    private static int hayCaminoAux2(Graph g, int o, int d, boolean[] visitados) { 
        visitados[o] = true;
        int costoMinimo = 1000000;
                 int costoCamino=0;
        if (o == d){
        visitados[o] = false;
           return 0;
        }
        else{
           ArrayList<Integer> hijos = g.getSuccessors(o);          
             
                for (Integer hijo: hijos){
                if (!visitados[hijo]){
                  costoCamino =g.getWeight(o,hijo)+ hayCaminoAux2(g, hijo, d, visitados);
                  visitados[hijo]=false;
                   if (costoCamino < costoMinimo)
                             { costoMinimo = costoCamino;}
                }
              
              
        
    
        }
    
}
          return costoMinimo;  
    }
    /**
     * Metodo para leer un archivo con los duenos de vehiculos y la empresa
     * Complejidad: Mejor y peor caso es O(n*n), donde n es son los duenos de
     * vehiculos y la empresa
     *
     * @param numeroDePuntos El numero de puntos es 1 de la empresa y n-1 de los
     *                       duenos de vehiculos
     * @return un grafo completo con la distancia mas corta entre todos los vertices
     */
    public static DigraphAM leerArchivo(int numeroDePuntos, float p) {
        final String nombreDelArchivo = "dataset-ejemplo-U=4-p=1.2.txt";// "dataset-ejemplo-U="+numeroDePuntos+"-p="+p+".txt";
        DigraphAM grafo = new DigraphAM(numeroDePuntos);
        try {
            BufferedReader br = new BufferedReader(new FileReader(nombreDelArchivo));
            String lineaActual = br.readLine();
            for (int i = 1; i <= 3; i++) // Descarta las primeras 3 lineas
                lineaActual = br.readLine();
            lineaActual = br.readLine();
            for (int i = 1; i <= numeroDePuntos; i++) { // Descarta los nombres y coordenadas de los vertices
                lineaActual = br.readLine();
            }
            for (int i = 1; i <= 3; i++) // Descarta las siguientes 3 lineas
                lineaActual = br.readLine();
            while (lineaActual != null) { // Mientras no llegue al fin del archivo. Lee la informacion de las aristas
                String[] cadenaParticionada = lineaActual.split(" ");
                grafo.addArc(Integer.parseInt(cadenaParticionada[0]) - 1, Integer.parseInt(cadenaParticionada[1]) - 1,
                        Integer.parseInt(cadenaParticionada[2]));
                lineaActual = br.readLine();
            }
        } catch (IOException ioe) {
            System.out.println("Error leyendo el archivo de entrada: " + ioe.getMessage());
        }
        return grafo;
    }

    public static LinkedList<LinkedList<Integer>> vehiculos(Graph grafo, float p) {
        boolean[] visit = new boolean[grafo.size()+1];
        return vehiculos2(grafo, visit,p);
    }

    public static LinkedList<LinkedList<Integer>> vehiculos2(Graph grafo, boolean[] visit,float p) {

        LinkedList<LinkedList<Integer>> permutacionParaCadaSubconjunto = new LinkedList<LinkedList<Integer>>();
        int dueno = 1;
        int contador = 1;
        float aux = 0;
        LinkedList<Integer> permutacion = new LinkedList<Integer>();
        while (dueno <= grafo.size()) {
            System.out.println("|-------------");
            System.out.println("|Dueño: " + dueno);
            System.out.println("|Contador: " + contador);
            System.out.println("|-------------");
            if (contador == 1) { // Si el contador es 1, crear una nueva permutacion
                permutacion = new LinkedList<Integer>();
                visit[dueno] = true;
                 aux = hayCamino2(grafo, dueno, 0)*p;
                System.out.println("CONT1, "+dueno+" , "+visit[dueno]);
                permutacion.add(dueno);
               
                System.out.println("Aux = "+aux);
                dueno++;
                contador++;
            } else { // Sino, seguir insertando en la permutacion actual
                //try{
                if (!visit[dueno]) {
                    System.out.println("No lo he visitado: " + dueno);
                    permutacion.add(dueno);
                    System.out.println(permutacion);
                    visit[dueno] = true;
                    System.out.println("Dueño: "+dueno+" pregunta: Me han visitado? "+visit[dueno]);
                    dueno++;
                    contador++;
                    if (contador == 6 || dueno == grafo.size()) { // Si esto se cumple, agregar la permutacion a la
                        //System.out.println("hola1");                                   // respuesta
                        float aux2 = 0;
                        if (permutacion.size() > 1){
                        for (int i = 0; i < permutacion.size()-1; i++) {
                            //System.out.println(permutacion);
                            aux2 += hayCamino2(grafo, permutacion.get(i), permutacion.get(i + 1));
                            //System.out.println("hola: "+aux2);
                            }
                        }
                        aux2 += hayCamino2(grafo, permutacion.getLast(), 0);
                        contador = 1;
                        if (aux2 <= aux) {
                            permutacionParaCadaSubconjunto.add(permutacion);
                        } else {
                            dueno = permutacion.get(permutacion.size()-1);
                            System.out.println("Dueño: "+dueno);
                           visit[permutacion.getLast()]=false;
                           System.out.println("Establezco a "+permutacion.getLast()+"como false");
                           System.out.println("Permutación: "+permutacion);
                            permutacion.remove(permutacion.getLast());
                            System.out.println("Permutación 2: "+permutacion);
                            permutacionParaCadaSubconjunto.add(permutacion);
                        }
                    }
                } else if (visit[dueno]){
                    System.out.println("Lo he visitado: " + dueno);
                    dueno++;
                }
            }
            //catch(Exception ioe){}
            //}
        }
        permutacionParaCadaSubconjunto.add(permutacion);
        System.out.println(permutacionParaCadaSubconjunto);
        return permutacionParaCadaSubconjunto;
    }
    

    /**
     * Metodo para escribir un archivo con la respuesta Complejidad: Mejor y peor
     * caso es O(n), donde n son los duenos de vehiculo y la empresa
     *
     * @param permutacionParaCadaSubconjunto es una lista de listas con la
     *                                       permutacion para cada subconjunto de la
     *                                       particion de duenos de vehiculo
     */

    public static void main(String[] args) {

        DigraphAM grafo = leerArchivo(5, 1.2f);
        // Asignar los vehiculos compartidos
        long startTime = System.currentTimeMillis();
        System.out.println(grafo.size());
        LinkedList<LinkedList<Integer>> permutacionParaCadaSubconjunto = vehiculos(grafo, 1.2f);
        long estimatedTime = System.currentTimeMillis() - startTime;
        System.out.println("El algoritmo tomo un tiempo de: " + estimatedTime + " ms");


    }
}
