import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.ArrayList;
import javafx.util.Pair; 
import java.awt.List;
import java.util.Collections;
import java.util.Comparator;
import java.lang.Runtime;
/**
 *  
 * @author David Alzate Cardona
 * @author Laura Alzate Madrid
 */
public class main {
    public static ArrayList<Pair<Integer, Double>> mapa = new ArrayList<Pair<Integer, Double>>();
    private static Pair<Double,Double> uno= new Pair<Double,Double>(0.9,0.9);
    static ArrayList<String> mapValues = new ArrayList<String>();
/**
 *  
 * este metodo se encarga de hallar la distancia de dos puntos usando pitagoras
 * 
 */
    
    public static double distancia(Double a, Double b,Double a2, Double b2)
    {

        double x = ((a-a2)*(a-a2)+(b-b2)*(b-b2));

        double c = Math.sqrt(x);

        return c;
    }

    /**
     * Metodo para leer un archivo con los duenos de vehiculos y la empresa
     * 
     * vehiculos y la empresa
     *
     * @param numeroDePuntos El numero de puntos es 1 de la empresa y n-1 de los
     *                       duenos de vehiculos
     * @return un grafo completo con la distancia mas corta entre todos los vertices
     */
    public static DigraphAM leerArchivo(int numeroDePuntos) {
        final String nombreDelArchivo = "dataset-ejemplo-U=205-p=1.1.txt";// "dataset-ejemplo-U="+numeroDePuntos+"-p="+p+".txt";
        DigraphAM grafo = new DigraphAM(numeroDePuntos);
        try {
            BufferedReader br = new BufferedReader(new FileReader(nombreDelArchivo));
            String lineaActual = br.readLine();
            for (int i = 1; i <= 3; i++) // Descarta las primeras 3 lineas
                lineaActual = br.readLine();
            lineaActual = br.readLine();
            for (int i = 1; i <= numeroDePuntos; i++) { // Descarta los nombres y coordenadas de los vertices
                String[] cadenaParticionada = lineaActual.split(" ");
                if(i==1){

                    uno=new Pair(Double.parseDouble(cadenaParticionada[1]),Double.parseDouble(cadenaParticionada[2]));
                }
                else{
                    double aux=distancia(uno.getKey(),uno.getValue(),Double.parseDouble(cadenaParticionada[1]),Double.parseDouble(cadenaParticionada[2]));
                    mapa.add(new Pair(Integer.parseInt(cadenaParticionada[0])-1,aux));
                }
                lineaActual = br.readLine();
            }
            for (int i = 1; i <= 3; i++) // Descarta las siguientes 3 lineas
                lineaActual = br.readLine();
            while (lineaActual != null) { // Mientras no llegue al fin del archivo. Lee la informacion de las aristas
                String[] cadenaParticionada = lineaActual.split(" ");
                grafo.addArc(Integer.parseInt(cadenaParticionada[0])-1 , Integer.parseInt(cadenaParticionada[1])-1 ,
                    Integer.parseInt(cadenaParticionada[2]));
                lineaActual = br.readLine();
            }
        } catch (IOException ioe) {
            System.out.println("Error leyendo el archivo de entrada: " + ioe.getMessage());
        }

        Collections.sort(mapa, new Comparator<Pair<Integer, Double>>() {
                @Override
                public int compare(final Pair<Integer, Double> p1, final Pair<Integer, Double> p2) {

                    return p2.getValue().compareTo(p1.getValue());
                }
            });

        return grafo;
    }
/**
 *  
 * metodo que retorna el conjunto que tiene el conjunto de autos con las personas que recoge 
 * 
 */
    public static  ArrayList<ArrayList<Integer>> vehiculos(Graph grafo, float p) {
        boolean[] visit = new boolean[grafo.size()+1];
        return vehiculos2(grafo, visit,p);
    }
/**
 *  
 * metodo que retorna la posicion del arreglo donde se encuentra el valor 'a'
 *@param a es el numero que vamos a buscar en el arreglo
 */
    public static int posicion(int a)
    {

        for(int i=0;i<mapa.size();++i)
        {
            if(mapa.get(i).getKey()==a)
            {
                return i-1;
            }
        }
        return -1;
    }
/**
 *  
 * metodo auxiliar que retorna el conjunto de conjuntos de autos
 * @param grafo es el grafo donde tenemos la informacion
 * @visit para saber si ya esta visitado el nodo
 * @p 
 */
    public static  ArrayList<ArrayList<Integer>> vehiculos2(Graph grafo, boolean[] visit,float p) {

        ArrayList<ArrayList<Integer>> permutacionParaCadaSubconjunto = new ArrayList<ArrayList<Integer>>();
        int personas=1;
        int contador = 1;
        float aux = 0;
        int s=0;
        ArrayList<Integer> permutacion = new ArrayList<Integer>();
        while (personas < grafo.size()) {
            Pair<Integer,Double> recorrido=mapa.get(s);

            permutacion = new ArrayList<Integer>();
            if (!visit[recorrido.getKey()]) {   
                visit[recorrido.getKey()] = true;
                aux = grafo.getWeight(recorrido.getKey(),0)*p;
                permutacion.add(recorrido.getKey());
                personas++;

                ArrayList<Integer> hijos = grafo.getSuccessors(recorrido.getKey()); 
                int menor =grafo.getWeight(recorrido.getKey(),hijos.get(1));
                int inicial=recorrido.getKey();
                int cercano=hijos.get(1);
                float aux2 = 0;
                for(int i=0;i<4 && personas <= grafo.size();i++){        
                    for (Integer hijo: hijos){
                        if (!visit[hijo] && hijo!=0){
                            if (grafo.getWeight(inicial,hijo) <=menor)
                            { cercano = hijo;
                                menor=grafo.getWeight(inicial,cercano);

                            }
                        }
                    }
                    
                    if (!visit[cercano]  && cercano!=0 && mapa.get(posicion(cercano)).getValue()<=recorrido.getValue()){
                        visit[cercano] = true;
                        inicial=cercano;

                        permutacion.add(cercano);
                        personas++;
                    }

                    hijos=grafo.getSuccessors(inicial);
                    menor=grafo.getWeight(inicial,hijos.get(1));
                }
                contador++;

                
                if (permutacion.size() > 1){
                    for (int i = 0; i < permutacion.size()-1; i++) {
                        //System.out.println(permutacion);
                        aux2 += grafo.getWeight(permutacion.get(i),permutacion.get(i+1));
                        //System.out.println("hola: "+aux2);
                    }
                }

                aux2 +=grafo.getWeight(permutacion.get(permutacion.size()-1),0);
                if (aux2 <= aux) {
                    permutacionParaCadaSubconjunto.add(permutacion);
                } else {
                    while(aux2 >= aux && permutacion.size()>1){
                        visit[permutacion.get(permutacion.size()-1)]=false;
                        aux2 -=grafo.getWeight(permutacion.get(permutacion.size()-1),0);
                        aux2-=grafo.getWeight(permutacion.get(permutacion.size()-2),permutacion.get(permutacion.size()-1));
                        permutacion.remove(permutacion.get(permutacion.size()-1));
                        aux2 +=grafo.getWeight(permutacion.get(permutacion.size()-1),0);
                        personas--;
                    }
                    //System.out.println("yendo solo: "+ aux);
                    //System.out.println("yendo acompañado :"+ aux2);
                    permutacionParaCadaSubconjunto.add(permutacion);
                }
            } else if (visit[contador]){

                contador++;
            }
            ++s;
        }
       

        System.out.println(permutacionParaCadaSubconjunto);
        return permutacionParaCadaSubconjunto;
    }

    /**
     *
     * @param permutacionParaCadaSubconjunto es una lista de listas con la
     *                                       permutacion para cada subconjunto de la
     *                                       particion de duenos de vehiculo
     */

    public static void main(String[] args) {

        DigraphAM grafo = leerArchivo(205);
        // Asignar los vehiculos compartidos
        long startTime = System.currentTimeMillis();
      
         ArrayList<ArrayList<Integer>> permutacionParaCadaSubconjunto = vehiculos(grafo, 1.2f);
        long estimatedTime = System.currentTimeMillis() - startTime;
        System.out.println("El algoritmo tomo un tiempo de: " + estimatedTime + " ms");
        System.out.println("numero de carros: " + permutacionParaCadaSubconjunto.size());
      
    }
}
